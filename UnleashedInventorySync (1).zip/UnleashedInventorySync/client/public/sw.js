// PWA Service Worker - Cache-Busting Solution
const CACHE_VERSION = Date.now(); // Force cache invalidation
const CACHE_NAME = 'retail-restock-v' + CACHE_VERSION;

console.log('SW: Starting service worker with cache version:', CACHE_VERSION);

// Install event - immediate activation
self.addEventListener('install', (event) => {
  console.log('SW: Installing - skipping waiting');
  event.waitUntil(
    caches.keys().then(cacheNames => {
      // Delete ALL existing caches
      return Promise.all(
        cacheNames.map(cacheName => {
          console.log('SW: Deleting cache:', cacheName);
          return caches.delete(cacheName);
        })
      );
    }).then(() => {
      console.log('SW: All caches cleared, skipping waiting');
      return self.skipWaiting();
    })
  );
});

// Activate event - immediate client claim
self.addEventListener('activate', (event) => {
  console.log('SW: Activating - claiming clients');
  event.waitUntil(
    self.clients.claim().then(() => {
      console.log('SW: All clients claimed');
      // Notify all clients to reload
      return self.clients.matchAll();
    }).then(clients => {
      clients.forEach(client => {
        console.log('SW: Sending reload message to client');
        client.postMessage({ 
          type: 'SW_UPDATED',
          version: CACHE_VERSION,
          message: 'Service Worker updated - reloading'
        });
      });
    })
  );
});

// Fetch event - Network-first with aggressive cache busting
self.addEventListener('fetch', (event) => {
  const request = event.request;
  
  // Skip non-GET requests
  if (request.method !== 'GET') {
    return;
  }

  event.respondWith(
    // Always fetch from network with cache busting
    fetch(addCacheBuster(request.url), {
      headers: {
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      }
    })
    .then(response => {
      console.log('SW: Network response for', request.url, '- Status:', response.status);
      if (response.ok) {
        return response;
      }
      throw new Error('Network response not ok: ' + response.status);
    })
    .catch(error => {
      console.log('SW: Network failed for', request.url, '- Error:', error);
      
      // If root request fails, return refresh page
      if (request.url.endsWith('/') || request.url.includes('index.html')) {
        return new Response(
          `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Loading Restock App</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="refresh" content="3;url=/">
    <style>
        body { margin: 0; font-family: system-ui; background: linear-gradient(135deg, #007bff 0%, #28a745 100%); color: white; text-align: center; padding: 100px 20px; }
        .spinner { width: 40px; height: 40px; border: 4px solid rgba(255,255,255,0.3); border-top: 4px solid white; border-radius: 50%; animation: spin 1s linear infinite; margin: 20px auto; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    </style>
</head>
<body>
    <h1>🏪 Restock App Loading</h1>
    <div class="spinner"></div>
    <p>Connecting to server...</p>
    <p><small>Cache Version: ${CACHE_VERSION}</small></p>
    <script>
        console.log('SW Fallback: Attempting to reload in 3 seconds');
        setTimeout(() => {
            console.log('SW Fallback: Reloading page');
            window.location.reload(true);
        }, 3000);
    </script>
</body>
</html>`,
          { 
            headers: { 
              'Content-Type': 'text/html',
              'Cache-Control': 'no-cache, no-store, must-revalidate'
            } 
          }
        );
      }
      
      // For other requests, return basic error
      return new Response('Service Unavailable', { status: 503 });
    })
  );
});

// Helper function to add cache buster
function addCacheBuster(url) {
  const separator = url.includes('?') ? '&' : '?';
  return url + separator + '_cb=' + Date.now() + '&_v=' + CACHE_VERSION;
}

// Message handling
self.addEventListener('message', (event) => {
  console.log('SW: Received message:', event.data);
  
  if (event.data && event.data.type === 'SKIP_WAITING') {
    console.log('SW: Skipping waiting');
    self.skipWaiting();
  }
  
  if (event.data && event.data.type === 'CLEAR_CACHE') {
    console.log('SW: Clearing all caches');
    event.waitUntil(
      caches.keys().then(cacheNames => 
        Promise.all(cacheNames.map(cache => caches.delete(cache)))
      )
    );
  }
});