import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer } from "http";
import { registerRoutes } from "./routes";
import { log } from "./vite";

// Vercel serverless function handler
const app = express();

// Parse JSON bodies
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// CORS headers for Vercel
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS, PATCH');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
  } else {
    next();
  }
});

// Security headers
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'origin-when-cross-origin');
  next();
});

// Static file serving for Vercel
app.use(express.static(path.join(__dirname, '../client/public'), {
  maxAge: process.env.NODE_ENV === 'production' ? '1h' : '0',
  etag: false,
  lastModified: false
}));

// Create HTTP server
const server = createServer(app);

// Register API routes
registerRoutes(app);

// PWA Service Worker with Vercel-optimized caching
app.get('/sw.js', (req, res) => {
  res.setHeader('Content-Type', 'application/javascript');
  res.setHeader('Cache-Control', 'public, max-age=0, must-revalidate');
  res.setHeader('Service-Worker-Allowed', '/');
  
  res.send(`
// Vercel-Optimized Service Worker
const CACHE_NAME = 'retail-restock-v' + Date.now();
const CACHE_URLS = [
  '/',
  '/manifest.json',
  '/app-icon.svg',
  '/app-icon-192.png',
  '/app-icon-512.png'
];

// Install - cache essential resources
self.addEventListener('install', (event) => {
  console.log('SW: Installing with cache version:', CACHE_NAME);
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('SW: Caching essential resources');
        return cache.addAll(CACHE_URLS);
      })
      .then(() => self.skipWaiting())
  );
});

// Activate - clean old caches
self.addEventListener('activate', (event) => {
  console.log('SW: Activating');
  event.waitUntil(
    caches.keys()
      .then(cacheNames => {
        return Promise.all(
          cacheNames
            .filter(name => name !== CACHE_NAME)
            .map(name => {
              console.log('SW: Deleting old cache:', name);
              return caches.delete(name);
            })
        );
      })
      .then(() => {
        console.log('SW: Taking control of all clients');
        return self.clients.claim();
      })
  );
});

// Fetch - network first for API, cache first for static resources
self.addEventListener('fetch', (event) => {
  const { request } = event;
  
  // Skip non-GET requests
  if (request.method !== 'GET') {
    return;
  }
  
  // API requests - always network first
  if (request.url.includes('/api/')) {
    event.respondWith(
      fetch(request)
        .then(response => {
          console.log('SW: API request successful:', request.url);
          return response;
        })
        .catch(error => {
          console.log('SW: API request failed:', request.url, error);
          return new Response(
            JSON.stringify({ error: 'Network unavailable' }),
            { 
              status: 503,
              headers: { 'Content-Type': 'application/json' }
            }
          );
        })
    );
    return;
  }
  
  // Static resources - cache first with network fallback
  event.respondWith(
    caches.match(request)
      .then(response => {
        if (response) {
          console.log('SW: Serving from cache:', request.url);
          return response;
        }
        
        console.log('SW: Fetching from network:', request.url);
        return fetch(request)
          .then(networkResponse => {
            // Cache successful responses
            if (networkResponse.ok) {
              const responseClone = networkResponse.clone();
              caches.open(CACHE_NAME)
                .then(cache => cache.put(request, responseClone));
            }
            return networkResponse;
          });
      })
      .catch(error => {
        console.log('SW: Request failed:', request.url, error);
        
        // Return offline page for navigation requests
        if (request.mode === 'navigate') {
          return new Response(\`
<!DOCTYPE html>
<html>
<head>
    <title>Offline - Retail Restock</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body { 
            margin: 0; 
            font-family: system-ui; 
            background: linear-gradient(135deg, #007bff 0%, #28a745 100%); 
            color: white; 
            text-align: center; 
            padding: 100px 20px; 
        }
        .container { max-width: 400px; margin: 0 auto; }
        h1 { font-size: 2rem; margin-bottom: 20px; }
        button { 
            background: white; 
            color: #007bff; 
            border: none; 
            padding: 15px 30px; 
            border-radius: 10px; 
            font-size: 1rem; 
            cursor: pointer; 
            margin: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>📱 Retail Restock</h1>
        <p>You're currently offline</p>
        <p>The app will automatically reconnect when your internet connection is restored.</p>
        <button onclick="window.location.reload()">Try Again</button>
    </div>
</body>
</html>
          \`, {
            headers: { 'Content-Type': 'text/html' }
          });
        }
        
        return new Response('Offline', { status: 503 });
      })
  );
});

// Handle messages from main thread
self.addEventListener('message', (event) => {
  console.log('SW: Received message:', event.data);
  
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
  
  if (event.data && event.data.type === 'CLEAR_CACHE') {
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cache => caches.delete(cache))
      );
    });
  }
});
  `);
});

// PWA Manifest with Vercel configuration
app.get('/manifest.json', (req, res) => {
  res.setHeader('Content-Type', 'application/manifest+json');
  res.setHeader('Cache-Control', 'public, max-age=0, must-revalidate');
  
  const manifest = {
    name: "Retail Restock System",
    short_name: "Restock",
    description: "Professional retail inventory management system",
    start_url: "/",
    display: "standalone",
    background_color: "#007bff",
    theme_color: "#007bff",
    orientation: "portrait-primary",
    scope: "/",
    categories: ["business", "productivity"],
    icons: [
      {
        src: "/app-icon-192.png",
        sizes: "192x192",
        type: "image/png",
        purpose: "any maskable"
      },
      {
        src: "/app-icon-512.png",
        sizes: "512x512",
        type: "image/png",
        purpose: "any maskable"
      },
      {
        src: "/app-icon.svg",
        sizes: "any",
        type: "image/svg+xml",
        purpose: "any"
      }
    ],
    shortcuts: [
      {
        name: "Start Restock",
        short_name: "Restock",
        description: "Begin a new restock session",
        url: "/?action=restock",
        icons: [{ src: "/app-icon-192.png", sizes: "192x192" }]
      },
      {
        name: "View Reports",
        short_name: "Reports",
        description: "Access monthly reports",
        url: "/?action=reports",
        icons: [{ src: "/app-icon-192.png", sizes: "192x192" }]
      }
    ]
  };
  
  res.json(manifest);
});

// Main application route with Vercel optimization
app.get('*', (req, res) => {
  // Log request for debugging
  console.log('Vercel Request:', {
    path: req.path,
    userAgent: req.headers['user-agent']?.substring(0, 50),
    timestamp: new Date().toISOString()
  });

  res.setHeader('Content-Type', 'text/html');
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  
  const timestamp = Date.now();
  
  res.send(\`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Retail Restock System</title>
    
    <!-- PWA Configuration -->
    <link rel="manifest" href="/manifest.json">
    <meta name="theme-color" content="#007bff">
    
    <!-- iOS PWA Support -->
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <meta name="apple-mobile-web-app-title" content="Restock">
    <link rel="apple-touch-icon" href="/app-icon-192.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/app-icon-192.png">
    <link rel="apple-touch-icon" sizes="167x167" href="/app-icon-192.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/app-icon-192.png">
    
    <!-- Favicon -->
    <link rel="icon" type="image/svg+xml" href="/app-icon.svg">
    
    <!-- Cache Prevention -->
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: linear-gradient(135deg, #007bff 0%, #28a745 100%);
            color: white;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        
        .container {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            max-width: 600px;
            width: 100%;
            text-align: center;
        }
        
        h1 { font-size: 2.5rem; margin-bottom: 20px; font-weight: 700; }
        .subtitle { font-size: 1.2rem; margin-bottom: 30px; opacity: 0.9; }
        
        .status-section {
            background: rgba(255, 255, 255, 0.2);
            border-radius: 15px;
            padding: 20px;
            margin: 20px 0;
        }
        
        .status-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }
        
        .status-item {
            background: rgba(255, 255, 255, 0.1);
            padding: 15px;
            border-radius: 10px;
            text-align: center;
        }
        
        .status-label { font-size: 0.9rem; opacity: 0.8; margin-bottom: 5px; }
        .status-value { font-size: 1.2rem; font-weight: bold; }
        
        .actions { margin: 30px 0; }
        
        .btn {
            background: rgba(255, 255, 255, 0.9);
            color: #007bff;
            border: none;
            padding: 15px 30px;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: 600;
            margin: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
            min-width: 180px;
        }
        
        .btn:hover {
            background: white;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        
        .version-info {
            background: rgba(255, 255, 255, 0.1);
            padding: 20px;
            border-radius: 15px;
            margin: 20px 0;
            font-size: 0.9rem;
            text-align: left;
        }
        
        .pwa-badge {
            position: fixed;
            top: 20px;
            right: 20px;
            background: rgba(40, 167, 69, 0.9);
            color: white;
            padding: 10px 15px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            display: none;
        }
        
        .loading {
            width: 30px;
            height: 30px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-top: 3px solid white;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 10px auto;
        }
        
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        
        .success { color: #28a745; }
        .error { color: #dc3545; }
        .warning { color: #ffc107; }
        
        @media (max-width: 480px) {
            .container { padding: 20px; }
            h1 { font-size: 2rem; }
            .status-grid { grid-template-columns: 1fr; }
            .btn { min-width: 100%; margin: 5px 0; }
        }
        
        .deployment-info {
            position: fixed;
            bottom: 20px;
            left: 20px;
            background: rgba(0, 0, 0, 0.3);
            color: white;
            padding: 10px 15px;
            border-radius: 10px;
            font-size: 0.7rem;
            max-width: 300px;
        }
    </style>
</head>
<body>
    <div class="pwa-badge" id="pwa-badge">PWA Active on Vercel</div>
    
    <div class="container">
        <h1>🏪 Retail Restock System</h1>
        <p class="subtitle">Professional Inventory Management</p>
        
        <div class="status-section">
            <h3>System Status</h3>
            <div class="status-grid">
                <div class="status-item">
                    <div class="status-label">Platform</div>
                    <div class="status-value success">Vercel</div>
                </div>
                <div class="status-item">
                    <div class="status-label">Server</div>
                    <div class="status-value" id="server-status">
                        <div class="loading"></div>
                    </div>
                </div>
                <div class="status-item">
                    <div class="status-label">Database</div>
                    <div class="status-value" id="db-status">
                        <div class="loading"></div>
                    </div>
                </div>
                <div class="status-item">
                    <div class="status-label">Cache</div>
                    <div class="status-value success">Optimized</div>
                </div>
            </div>
        </div>
        
        <div class="actions">
            <button class="btn" onclick="startRestock()">🏪 Start Restock Session</button>
            <button class="btn" onclick="viewReports()">📊 Monthly Reports</button>
            <button class="btn" onclick="manageInventory()">📦 Manage Inventory</button>
            <button class="btn" onclick="openSettings()">⚙️ System Settings</button>
        </div>
        
        <div class="version-info">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                <div>
                    <strong>Version:</strong> <span id="version">${new Date().toISOString().split('T')[0]}</span><br>
                    <strong>Build:</strong> <span id="build-time">${timestamp}</span>
                </div>
                <div>
                    <strong>Load Time:</strong> <span id="load-time">Loading...</span><br>
                    <strong>PWA Mode:</strong> <span id="pwa-mode">Loading...</span>
                </div>
            </div>
        </div>
        
        <div id="results" style="display: none; background: rgba(255,255,255,0.2); padding: 20px; border-radius: 15px; margin: 20px 0;">
            <h4>Results</h4>
            <div id="output"></div>
        </div>
    </div>
    
    <div class="deployment-info">
        <strong>Platform:</strong> Vercel<br>
        <strong>Environment:</strong> Production<br>
        <strong>Cache Strategy:</strong> Network-first API, Cache-first static
    </div>
    
    <script>
        const startTime = Date.now();
        let systemData = { users: [], venues: [], products: [], loaded: false };
        
        // Service Worker Registration with Vercel optimization
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('/sw.js', {
                scope: '/',
                updateViaCache: 'none'
            }).then(registration => {
                console.log('SW: Registered successfully on Vercel');
                
                registration.addEventListener('updatefound', () => {
                    const newWorker = registration.installing;
                    newWorker.addEventListener('statechange', () => {
                        if (newWorker.state === 'installed' && registration.active) {
                            console.log('SW: New version available, updating...');
                            window.location.reload();
                        }
                    });
                });
            }).catch(error => {
                console.error('SW: Registration failed:', error);
            });
        }
        
        // PWA Detection
        function detectPWA() {
            const isStandalone = window.matchMedia('(display-mode: standalone)').matches;
            const isPWA = window.navigator.standalone || isStandalone;
            
            document.getElementById('pwa-mode').textContent = isPWA ? 'Yes' : 'No';
            
            if (isPWA) {
                document.getElementById('pwa-badge').style.display = 'block';
                // iOS status bar handling
                if (window.navigator.standalone) {
                    document.body.style.paddingTop = '30px';
                }
            }
            
            return isPWA;
        }
        
        // System Status Check
        async function checkSystemStatus() {
            try {
                const loadTime = Date.now() - startTime;
                document.getElementById('load-time').textContent = loadTime + 'ms';
                
                // Test server connectivity
                const healthResponse = await fetch('/api/health?_t=' + Date.now());
                if (healthResponse.ok) {
                    document.getElementById('server-status').innerHTML = '✓';
                    document.getElementById('server-status').className = 'status-value success';
                    
                    // Test database
                    const dbResponse = await fetch('/api/users?_t=' + Date.now());
                    if (dbResponse.ok) {
                        const users = await dbResponse.json();
                        systemData.users = users;
                        document.getElementById('db-status').innerHTML = '✓';
                        document.getElementById('db-status').className = 'status-value success';
                        systemData.loaded = true;
                    } else {
                        document.getElementById('db-status').innerHTML = '✗';
                        document.getElementById('db-status').className = 'status-value error';
                    }
                } else {
                    document.getElementById('server-status').innerHTML = '✗';
                    document.getElementById('server-status').className = 'status-value error';
                    document.getElementById('db-status').innerHTML = '✗';
                    document.getElementById('db-status').className = 'status-value error';
                }
            } catch (error) {
                console.error('System check failed:', error);
                document.getElementById('server-status').innerHTML = '✗';
                document.getElementById('server-status').className = 'status-value error';
                document.getElementById('db-status').innerHTML = '✗';
                document.getElementById('db-status').className = 'status-value error';
            }
        }
        
        // Action Handlers
        function startRestock() {
            showResults('🎯 <strong>Multi-Step Restock Workflow Ready</strong><br><br>Features:<br>• User and venue selection<br>• Product inventory management with par levels<br>• Weekly sales analysis with Shopify pricing<br>• Automatic order creation in Unleashed<br>• Professional order confirmation');
        }
        
        function viewReports() {
            showResults('📊 <strong>Comprehensive Monthly Reporting</strong><br><br>Analytics:<br>• 6-month trend analysis with bar charts<br>• Venue-specific performance metrics<br>• Professional PDF generation<br>• Automated email delivery system<br>• Authentic Shopify/WOLFF32 pricing integration');
        }
        
        function manageInventory() {
            showResults('📦 <strong>Advanced Inventory Management</strong><br><br>Capabilities:<br>• Real-time par level management<br>• Product catalog with search and filters<br>• Venue-specific product assignments<br>• Direct Unleashed API integration<br>• Bulk operations and imports');
        }
        
        function openSettings() {
            showResults('⚙️ <strong>System Administration</strong><br><br>Configuration:<br>• User management and permissions<br>• Venue setup and configuration<br>• API settings and credentials<br>• Cache management tools<br>• System health monitoring');
        }
        
        function showResults(message) {
            document.getElementById('results').style.display = 'block';
            document.getElementById('output').innerHTML = message;
            document.getElementById('results').scrollIntoView({ behavior: 'smooth' });
        }
        
        // Initialize
        window.addEventListener('load', () => {
            detectPWA();
            checkSystemStatus();
        });
        
        // Handle PWA install prompt
        window.addEventListener('beforeinstallprompt', (e) => {
            e.preventDefault();
            console.log('PWA install prompt available on Vercel');
        });
        
        // Handle visibility changes for data refresh
        document.addEventListener('visibilitychange', () => {
            if (!document.hidden) {
                checkSystemStatus();
            }
        });
        
        // Error handling
        window.addEventListener('error', (event) => {
            console.error('Application error:', event.error);
        });
        
        window.addEventListener('unhandledrejection', (event) => {
            console.error('Unhandled promise rejection:', event.reason);
            event.preventDefault();
        });
    </script>
</body>
</html>\`);
});

// Export for Vercel
export default app;