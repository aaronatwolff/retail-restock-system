import { db } from '../db.js';
import { restockSessions, venues, products } from '../../shared/schema.js';
import { eq, and, gte, lt, desc } from 'drizzle-orm';
import { UnleashedService } from './unleashed.js';

export interface MonthlyReportData {
  venue: {
    id: number;
    name: string;
    code: string;
  };
  period: {
    month: number;
    year: number;
    displayName: string;
    startDate: Date;
    endDate: Date;
  };
  summary: {
    totalEstimatedSales: number;
    totalPurchaseCosts: number;
    grossProfit: number;
    profitMargin: number;
    transactionCount: number;
  };
  topProducts: Array<{
    productCode: string;
    productName: string;
    unitsSold: number;
    revenue: number;
    cost: number;
    profit: number;
    profitMargin: number;
  }>;
  trends: {
    salesVsPreviousMonth: number;
    profitVsPreviousMonth: number;
    trendDirection: 'up' | 'down' | 'stable';
  };
  monthlyTrends: Array<{
    month: string;
    year: number;
    estimatedSales: number;
    purchaseCosts: number;
  }>;
}

export class ReportingService {
  private unleashedService: UnleashedService;

  constructor() {
    this.unleashedService = new UnleashedService();
  }

  async generateMonthlyReport(venueId: number, month: number, year: number): Promise<MonthlyReportData> {
    console.log(`Generating monthly report for venue ${venueId}, ${month}/${year}`);

    // Get venue information
    const venue = await db.select().from(venues).where(eq(venues.id, venueId)).limit(1);
    if (!venue[0]) {
      throw new Error(`Venue ${venueId} not found`);
    }

    // Calculate date range
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 1);
    const displayName = new Date(year, month - 1, 1).toLocaleDateString('en-AU', { 
      month: 'long', 
      year: 'numeric' 
    });

    // Get restock sessions for the month using visit_date
    const sessions = await db.select()
      .from(restockSessions)
      .where(and(
        eq(restockSessions.venueId, venueId),
        gte(restockSessions.visitDate, startDate.toISOString().split('T')[0]),
        lt(restockSessions.visitDate, endDate.toISOString().split('T')[0]),
        eq(restockSessions.status, 'completed')
      ))
      .orderBy(desc(restockSessions.visitDate));

    console.log(`Found ${sessions.length} completed sessions for ${venue[0].name} in ${displayName}`);

    // Process session data
    const summary = {
      totalEstimatedSales: 0,
      totalPurchaseCosts: 0,
      grossProfit: 0,
      profitMargin: 0,
      transactionCount: sessions.length
    };

    const productMap = new Map<string, {
      name: string;
      unitsSold: number;
      revenue: number;
      cost: number;
    }>();

    // Process each session
    for (const session of sessions) {
      if (session.itemsData && Array.isArray(session.itemsData)) {
        for (const item of session.itemsData) {
          // Get pricing (use fallback for testing)
          let shopifyPrice = 0;
          let wolff32Price = 0;

          try {
            shopifyPrice = await this.unleashedService.getShopifyPrice(item.productCode) || 0;
            wolff32Price = await this.unleashedService.getWolff32Price(item.productCode) || 0;
          } catch (error) {
            console.warn(`Failed to get pricing for ${item.productCode}:`, error);
            // Skip pricing calculation when not available
            shopifyPrice = 0;
            wolff32Price = 0;
          }

          const soldQuantity = item.soldQuantity || 0;
          const purchaseQuantity = item.quantity || 0;

          const revenue = soldQuantity * shopifyPrice;
          const cost = purchaseQuantity * wolff32Price;

          summary.totalEstimatedSales += revenue;
          summary.totalPurchaseCosts += cost;

          // Track product performance
          const existing = productMap.get(item.productCode) || {
            name: item.productName,
            unitsSold: 0,
            revenue: 0,
            cost: 0
          };

          productMap.set(item.productCode, {
            name: existing.name,
            unitsSold: existing.unitsSold + soldQuantity,
            revenue: existing.revenue + revenue,
            cost: existing.cost + cost
          });
        }
      }
    }

    summary.grossProfit = summary.totalEstimatedSales - summary.totalPurchaseCosts;
    summary.profitMargin = summary.totalEstimatedSales > 0 
      ? (summary.grossProfit / summary.totalEstimatedSales) * 100 
      : 0;

    // Get top 5 products
    const topProducts = Array.from(productMap.entries())
      .map(([code, data]) => ({
        productCode: code,
        productName: data.name,
        unitsSold: data.unitsSold,
        revenue: data.revenue,
        cost: data.cost,
        profit: data.revenue - data.cost,
        profitMargin: data.revenue > 0 ? ((data.revenue - data.cost) / data.revenue) * 100 : 0
      }))
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 5);

    // Get 6-month trends
    const monthlyTrends = await this.get6MonthTrends(venueId, month, year);

    // Calculate trend vs previous month
    const currentMonthIndex = monthlyTrends.findIndex(t => t.month === displayName.split(' ')[0] && t.year === year);
    const previousMonth = currentMonthIndex > 0 ? monthlyTrends[currentMonthIndex - 1] : null;
    
    const salesVsPreviousMonth = previousMonth 
      ? ((summary.totalEstimatedSales - previousMonth.estimatedSales) / previousMonth.estimatedSales) * 100 
      : 0;
    
    const profitVsPreviousMonth = previousMonth 
      ? ((summary.grossProfit - (previousMonth.estimatedSales - previousMonth.purchaseCosts)) / (previousMonth.estimatedSales - previousMonth.purchaseCosts)) * 100 
      : 0;

    const trendDirection: 'up' | 'down' | 'stable' = 
      salesVsPreviousMonth > 5 ? 'up' : 
      salesVsPreviousMonth < -5 ? 'down' : 'stable';

    return {
      venue: {
        id: venue[0].id,
        name: venue[0].name,
        code: venue[0].code || ''
      },
      period: {
        month,
        year,
        displayName,
        startDate,
        endDate
      },
      summary,
      topProducts,
      trends: {
        salesVsPreviousMonth,
        profitVsPreviousMonth,
        trendDirection
      },
      monthlyTrends
    };
  }

  private async get6MonthTrends(venueId: number, currentMonth: number, currentYear: number): Promise<Array<{
    month: string;
    year: number;
    estimatedSales: number;
    purchaseCosts: number;
  }>> {
    const trends = [];
    
    for (let i = 5; i >= 0; i--) {
      const date = new Date(currentYear, currentMonth - 1 - i, 1);
      const month = date.getMonth();
      const year = date.getFullYear();
      
      const startDate = new Date(year, month, 1);
      const endDate = new Date(year, month + 1, 1);
      
      const sessions = await db.select()
        .from(restockSessions)
        .where(and(
          eq(restockSessions.venueId, venueId),
          gte(restockSessions.visitDate, startDate.toISOString().split('T')[0]),
          lt(restockSessions.visitDate, endDate.toISOString().split('T')[0]),
          eq(restockSessions.status, 'completed')
        ));

      let estimatedSales = 0;
      let purchaseCosts = 0;

      for (const session of sessions) {
        if (session.itemsData && Array.isArray(session.itemsData)) {
          for (const item of session.itemsData) {
            try {
              const shopifyPrice = await this.unleashedService.getShopifyPrice(item.productCode) || 0;
              const wolff32Price = await this.unleashedService.getWolff32Price(item.productCode) || 0;
              const soldQuantity = item.soldQuantity || 0;
              const purchaseQuantity = item.quantity || 0;
              
              estimatedSales += soldQuantity * shopifyPrice;
              purchaseCosts += purchaseQuantity * wolff32Price;
            } catch (error) {
              // Skip pricing errors for trends
            }
          }
        }
      }

      trends.push({
        month: date.toLocaleDateString('en-AU', { month: 'short' }),
        year,
        estimatedSales,
        purchaseCosts
      });
    }

    return trends;
  }

  async generateAllVenuesReport(month: number, year: number): Promise<MonthlyReportData[]> {
    console.log(`Generating reports for all venues for ${month}/${year}`);
    
    const allVenues = await db.select().from(venues);
    const reports = [];

    for (const venue of allVenues) {
      try {
        const report = await this.generateMonthlyReport(venue.id, month, year);
        reports.push(report);
      } catch (error) {
        console.error(`Failed to generate report for ${venue.name}:`, error);
      }
    }

    return reports;
  }

  generateReportHTML(reportData: MonthlyReportData): string {
    const { venue, period, summary, topProducts, trends, monthlyTrends } = reportData;
    
    // Generate 6-month chart bars (scale $0 - $1,000)
    const maxScale = 1000;
    const chartBars = monthlyTrends.map(trend => {
      const salesHeight = Math.min((trend.estimatedSales / maxScale) * 100, 100);
      const costsHeight = Math.min((trend.purchaseCosts / maxScale) * 100, 100);
      
      return `
        <div style="display: flex; flex-direction: column; align-items: center; margin: 0 8px;">
          <div style="height: 120px; display: flex; align-items: flex-end; margin-bottom: 5px;">
            <div style="width: 15px; height: ${salesHeight}%; background: linear-gradient(135deg, #2d3748, #1a202c); margin-right: 2px; border-radius: 2px 2px 0 0; box-shadow: 0 2px 4px rgba(0,0,0,0.1);"></div>
            <div style="width: 15px; height: ${costsHeight}%; background: linear-gradient(135deg, #e53e3e, #c53030); border-radius: 2px 2px 0 0; box-shadow: 0 2px 4px rgba(0,0,0,0.1);"></div>
          </div>
          <div style="font-size: 10px; text-align: center; color: #718096; font-weight: 500;">
            ${trend.month}<br>${trend.year}
          </div>
        </div>
      `;
    }).join('');

    return `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Monthly Report - ${venue.name} - ${period.displayName}</title>
        <meta charset="utf-8">
        <style>
          * { box-sizing: border-box; }
          body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; 
            margin: 0; 
            padding: 20px; 
            line-height: 1.6; 
            color: #2d3748;
            background: linear-gradient(135deg, #f7fafc 0%, #edf2f7 100%);
            min-height: 100vh;
          }
          .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.12);
            overflow: hidden;
            border: 1px solid #e2e8f0;
          }
          .header { 
            background: linear-gradient(135deg, #2d3748 0%, #1a202c 100%);
            color: white;
            text-align: center; 
            padding: 40px 20px;
            margin-bottom: 0;
            position: relative;
          }
          .header::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #e53e3e 0%, #c53030 100%);
          }
          .header h1 {
            margin: 0 0 10px 0;
            font-size: 2.5rem;
            font-weight: 700;
            text-shadow: 0 2px 4px rgba(0,0,0,0.3);
          }
          .header h2 {
            margin: 0;
            font-size: 1.5rem;
            font-weight: 400;
            opacity: 0.9;
          }
          .content {
            padding: 40px;
          }
          .venue-info { 
            background: linear-gradient(135deg, #4a5568 0%, #2d3748 100%);
            color: white;
            padding: 25px; 
            border-radius: 8px; 
            margin-bottom: 35px;
            box-shadow: 0 4px 12px rgba(45, 55, 72, 0.3);
            border-left: 4px solid #e53e3e;
          }
          .venue-info h3 {
            margin: 0 0 10px 0;
            font-size: 1.4rem;
            font-weight: 600;
          }
          .summary-grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); 
            gap: 20px; 
            margin-bottom: 35px; 
          }
          .metric-card { 
            background: white; 
            padding: 30px; 
            border-radius: 12px; 
            text-align: center; 
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            border: 1px solid #e2e8f0;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
          }
          .metric-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
          }
          .metric-value { 
            font-size: 2.5rem; 
            font-weight: 800; 
            margin-bottom: 8px;
            color: #1a202c;
          }
          .metric-label { 
            font-size: 16px; 
            color: #718096;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
          }
          .section-title {
            font-size: 1.8rem;
            font-weight: 700;
            color: #1a202c;
            margin: 35px 0 20px 0;
            padding-bottom: 10px;
            border-bottom: 3px solid #e53e3e;
            display: inline-block;
          }
          .chart-section { 
            margin: 35px 0; 
            padding: 30px; 
            background: #f8fafc; 
            border-radius: 8px; 
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            border: 1px solid #e2e8f0;
            border-left: 4px solid #718096;
          }
          .chart-container { 
            display: flex; 
            justify-content: center; 
            align-items: flex-end; 
            height: 180px; 
            margin: 25px 0; 
            position: relative;
            background: linear-gradient(to top, #f7fafc 0%, transparent 100%);
            border-radius: 8px;
            padding: 20px;
          }
          .chart-legend { 
            display: flex; 
            justify-content: center; 
            gap: 30px; 
            margin-top: 20px; 
            font-size: 14px;
            font-weight: 500;
          }
          .legend-item { 
            display: flex; 
            align-items: center; 
            gap: 8px; 
          }
          .legend-color { 
            width: 16px; 
            height: 16px; 
            border-radius: 4px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
          }
          .products-table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-top: 25px;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
          }
          .products-table th, .products-table td { 
            padding: 16px 20px; 
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
          }
          .products-table th { 
            background: linear-gradient(135deg, #2d3748 0%, #1a202c 100%);
            color: white;
            font-weight: 600;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 1px;
          }
          .products-table tr { 
            transition: background-color 0.3s ease;
          }
          .products-table tr:hover { 
            background-color: #f8fafc;
          }
          .products-table tr:nth-child(even) { 
            background: #f7fafc; 
          }
          .trend-indicator { 
            display: inline-flex; 
            align-items: center; 
            gap: 6px; 
            padding: 6px 12px; 
            border-radius: 6px; 
            font-size: 12px; 
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
          }
          .trend-up { 
            background: #2d3748;
            color: white;
            box-shadow: 0 2px 8px rgba(45, 55, 72, 0.3);
          }
          .trend-down { 
            background: linear-gradient(135deg, #e53e3e, #c53030);
            color: white;
            box-shadow: 0 2px 8px rgba(229, 62, 62, 0.3);
          }
          .trend-stable { 
            background: linear-gradient(135deg, #a0aec0, #718096);
            color: white;
            box-shadow: 0 2px 8px rgba(160, 174, 192, 0.3);
          }
          .y-axis {
            position: absolute;
            left: -50px;
            top: 0;
            height: 120px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            font-size: 10px;
            color: #6b7280;
          }
          @media print {
            body { padding: 15px; }
            .metric-card { break-inside: avoid; }
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Monthly Sales Report</h1>
            <h2>${venue.name} - ${period.displayName}</h2>
          </div>

          <div class="content">
            <div class="venue-info">
              <h3>📍 ${venue.name}</h3>
              <p style="margin: 0;"><strong>Report Period:</strong> ${period.displayName}</p>
              <p style="margin: 5px 0 0 0;"><strong>Transactions:</strong> ${summary.transactionCount} restock sessions</p>
              <p style="margin: 5px 0 0 0;"><strong>Generated:</strong> ${new Date().toLocaleDateString('en-AU', { 
                day: 'numeric', 
                month: 'long', 
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
              })}</p>
            </div>

        <div class="summary-grid">
          <div class="metric-card">
            <div class="metric-value">$${summary.totalEstimatedSales.toFixed(2)}</div>
            <div class="metric-label">Estimated Sales</div>
          </div>
          <div class="metric-card">
            <div class="metric-value">$${summary.totalPurchaseCosts.toFixed(2)}</div>
            <div class="metric-label">Purchase Costs</div>
          </div>
          <div class="metric-card">
            <div class="metric-value">$${summary.grossProfit.toFixed(2)}</div>
            <div class="metric-label">Gross Profit</div>
          </div>
          <div class="metric-card">
            <div class="metric-value">${summary.profitMargin.toFixed(1)}%</div>
            <div class="metric-label">Profit Margin</div>
          </div>
        </div>

            <div class="section-title">📊 6-Month Sales Trend</div>
            <div class="chart-section">
              <div class="chart-container">
                <div class="y-axis">
                  <span>$1,000</span>
                  <span>$750</span>
                  <span>$500</span>
                  <span>$250</span>
                  <span>$0</span>
                </div>
                ${chartBars}
              </div>
              <div class="chart-legend">
                <div class="legend-item">
                  <div class="legend-color" style="background: linear-gradient(135deg, #2d3748, #1a202c);"></div>
                  <span>Estimated Sales</span>
                </div>
                <div class="legend-item">
                  <div class="legend-color" style="background: linear-gradient(135deg, #e53e3e, #c53030);"></div>
                  <span>Purchase Costs</span>
                </div>
              </div>
            </div>

            ${trends.salesVsPreviousMonth !== 0 ? `
            <div style="text-align: center; margin: 20px 0;">
              <span class="trend-indicator trend-${trends.trendDirection}">
                ${trends.trendDirection === 'up' ? '↗' : trends.trendDirection === 'down' ? '↘' : '→'} 
                ${Math.abs(trends.salesVsPreviousMonth).toFixed(1)}% vs previous month
              </span>
            </div>
            ` : ''}

            <div class="section-title">🏆 Top Products Performance</div>
            <table class="products-table">
              <thead>
                <tr>
                  <th>Product</th>
                  <th>SKU</th>
                  <th>Units Sold</th>
                  <th>Revenue</th>
                  <th>Costs</th>
                  <th>Profit</th>
                  <th>Margin</th>
                </tr>
              </thead>
              <tbody>
                ${topProducts.map(product => `
                  <tr>
                    <td><strong>${product.productName}</strong></td>
                    <td><code>${product.productCode}</code></td>
                    <td>${product.unitsSold}</td>
                    <td><strong>$${product.revenue.toFixed(2)}</strong></td>
                    <td>$${product.cost.toFixed(2)}</td>
                    <td style="color: ${product.profit > 0 ? '#2d3748' : '#e53e3e'}"><strong>$${product.profit.toFixed(2)}</strong></td>
                    <td style="color: ${product.profitMargin > 0 ? '#2d3748' : '#e53e3e'}">${product.profitMargin.toFixed(1)}%</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>

            <div style="margin-top: 40px; padding: 20px; background: #f8fafc; border-radius: 8px; text-align: center; font-size: 13px; color: #718096; border-left: 4px solid #e53e3e;">
              <p style="margin: 0 0 5px 0;"><strong>📋 Report Summary:</strong> Generated from ${summary.transactionCount} completed restock sessions</p>
              <p style="margin: 0;"><strong>💰 Pricing:</strong> Sales data from Shopify AUD, cost data from WOLFF32 AUD via Unleashed API</p>
            </div>
          </div>
        </div>
      </body>
      </html>
    `;
  }
}