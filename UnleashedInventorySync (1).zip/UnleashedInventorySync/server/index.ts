import path from "path";
import express from "express";
import fs from "fs";
import { registerRoutes } from "./routes";
import { log } from "./vite";
import { apiRouteProtection, requestLogger, errorHandler } from "./middleware";

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Apply middleware for API route protection
app.use(apiRouteProtection);
app.use(requestLogger);

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  try {
    log("Starting server initialization...");
    
    // Register routes FIRST, before Vite middleware
    const server = await registerRoutes(app);
    log("Routes registered successfully");
    
    // Test database connection first
    try {
      log("Testing database connection...");
      const { db } = await import("./db.js");
      await db.execute('SELECT 1');
      log("Database connection successful");
      
      // Verify storage is working with database
      const { storage } = await import("./storage.js");
      const { validateDatabaseSchema } = await import("./health-check.js");
      
      const users = await storage.getUsers();
      const venues = await storage.getVenues();
      const products = await storage.getProducts();
      
      log(`Database storage verified - ${users.length} users, ${venues.length} venues, ${products.length} products found`);
      
      // Validate schema integrity
      const schemaValid = await validateDatabaseSchema();
      if (schemaValid) {
        log("Database schema validation passed");
      } else {
        log("Database schema validation failed - some data may be missing", "warn");
      }
    } catch (dbError) {
      log(`Database connection failed: ${dbError}`, "error");
      // Fallback to memory storage for development
      log("Falling back to memory storage for development");
      const storageModule = await import("./storage.js");
      (storageModule as any).storage = new (await import("./storage.js")).MemStorage();
    }

    // Routes already registered above

    // Apply comprehensive error handling
    app.use(errorHandler);

    // Skip Vite setup to serve HTML application directly

    // Serve static assets
    log("Setting up static file serving...");
    
    if (process.env.NODE_ENV === 'production') {
      // Serve built Vite assets from dist
      const distDir = path.resolve(process.cwd(), 'dist');
      log(`Serving built assets from: ${distDir}`);
      app.use(express.static(distDir));
    }
    
    // Always serve public folder for additional static files
    const staticDir = path.resolve(process.cwd(), 'client/public');
    log(`Serving static files from: ${staticDir}`);
    app.use(express.static(staticDir, {
      setHeaders: (res, filePath) => {
        // Set iframe-friendly headers for all static files
        res.setHeader('X-Frame-Options', 'ALLOWALL');
        res.setHeader('Content-Security-Policy', 'frame-ancestors *; default-src * data: blob: filesystem: about: ws: wss: \'unsafe-inline\' \'unsafe-eval\'; script-src * data: blob: \'unsafe-inline\' \'unsafe-eval\'; connect-src * data: blob: \'unsafe-inline\'; img-src * data: blob: \'unsafe-inline\'; frame-src * data: blob:; style-src * data: blob: \'unsafe-inline\'; font-src * data: blob:');
        res.setHeader('Referrer-Policy', 'no-referrer-when-downgrade');
        res.setHeader('Cross-Origin-Embedder-Policy', 'unsafe-none');
        res.setHeader('Cross-Origin-Opener-Policy', 'unsafe-none');
        
        // Prevent all caching to avoid asset conflicts
        res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
        res.setHeader('Pragma', 'no-cache');
        res.setHeader('Expires', '0');
      }
    }));
    
    // Block ALL potential React build assets and development requests with proper MIME types
    app.get([
      '/@*',           // Vite dev requests
      '/src/*',        // Source files
      '/assets/*',     // Asset files
      '*.ts',          // TypeScript files
      '*.tsx',         // React TypeScript files
      '/dist/*'        // Distribution files
    ], (req, res) => {
      console.log(`Blocked asset request: ${req.path}`);
      if (req.path.endsWith('.js') || req.path.endsWith('.ts') || req.path.endsWith('.tsx')) {
        res.setHeader('Content-Type', 'application/javascript');
        res.status(200).send('// Asset blocked - no module');
      } else if (req.path.endsWith('.css')) {
        res.setHeader('Content-Type', 'text/css');
        res.status(200).send('/* Asset blocked */');
      } else {
        res.setHeader('Content-Type', 'text/plain');
        res.status(200).send('Asset blocked');
      }
    });
    
    // Handle all JS files (including React build files) with proper JavaScript MIME type
    app.get(/.*\.js$/, (req, res) => {
      console.log(`Blocked JavaScript file: ${req.path}`);
      res.setHeader('Content-Type', 'application/javascript');
      res.status(200).send('// JavaScript file blocked - no module exports');
    });
    
    // Handle all CSS files with proper CSS MIME type
    app.get(/.*\.css$/, (req, res) => {
      console.log(`Blocked CSS file: ${req.path}`);
      res.setHeader('Content-Type', 'text/css');
      res.status(200).send('/* CSS file blocked */');
    });
    
    // Handle preview iframe issues with direct access page
    app.get('/', (req, res) => {
      console.log('ROOT: Serving direct access page');
      
      // Check if this is from Replit preview iframe (problematic)
      const userAgent = req.headers['user-agent'] || '';
      const isReplit = process.env.REPLIT_DOMAINS || req.headers['x-forwarded-for'];
      
      if (isReplit && userAgent.includes('HeadlessChrome')) {
        // Serve direct access page for preview issues
        const fs = require('fs');
        const htmlPath = path.resolve(process.cwd(), 'client/public/direct.html');
        const htmlContent = fs.readFileSync(htmlPath, 'utf8');
        res.setHeader('Content-Type', 'text/html');
        res.send(htmlContent);
        return;
      }
      
      console.log('ROOT: Serving clean application for production');
      
      // Aggressive cache busting and iframe compatibility
      res.setHeader('X-Frame-Options', 'ALLOWALL');
      res.setHeader('Content-Security-Policy', 'frame-ancestors *; default-src * data: blob: filesystem: about: ws: wss: \'unsafe-inline\' \'unsafe-eval\'; script-src * data: blob: \'unsafe-inline\' \'unsafe-eval\'; connect-src * data: blob: \'unsafe-inline\'; img-src * data: blob: \'unsafe-inline\'; frame-src * data: blob:; style-src * data: blob: \'unsafe-inline\'; font-src * data: blob:');
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate, max-age=0, proxy-revalidate, s-maxage=0');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
      res.setHeader('Surrogate-Control', 'no-store');
      res.setHeader('ETag', 'W/"' + Date.now() + '"');
      res.setHeader('Last-Modified', new Date().toUTCString());
      res.setHeader('Vary', '*');
      
      // PWA-READY APPLICATION with Cache Invalidation
      const timestamp = Date.now();
      res.setHeader('Content-Type', 'text/html');
      res.send(`<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Retail Restock System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <link rel="manifest" href="/manifest.json">
    <link rel="icon" type="image/svg+xml" href="/app-icon.svg">
    <style>
        body { 
            margin: 0; 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
            background: linear-gradient(135deg, #007bff 0%, #28a745 100%); 
            color: white; 
            text-align: center; 
            padding: 20px;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }
        .container { 
            background: rgba(255, 255, 255, 0.1); 
            color: white; 
            padding: 40px; 
            border-radius: 20px; 
            max-width: 600px; 
            width: 100%;
            backdrop-filter: blur(10px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }
        h1 { margin-bottom: 30px; font-size: 2.5em; }
        .status { 
            background: rgba(255,255,255,0.2); 
            padding: 20px; 
            margin: 20px 0; 
            border-radius: 15px; 
        }
        .btn { 
            background: #ffffff; 
            color: #007bff; 
            border: none; 
            padding: 15px 30px; 
            border-radius: 10px; 
            font-size: 16px; 
            font-weight: bold;
            margin: 10px; 
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(0,0,0,0.2); }
        .loading { 
            width: 40px; 
            height: 40px; 
            border: 4px solid rgba(255,255,255,0.3); 
            border-top: 4px solid white; 
            border-radius: 50%; 
            animation: spin 1s linear infinite; 
            margin: 20px auto;
        }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        .pulse { animation: pulse 2s infinite; }
        @keyframes pulse { 0% { opacity: 1; } 50% { opacity: 0.5; } 100% { opacity: 1; } }
        .cache-info {
            background: rgba(255,255,255,0.1);
            padding: 15px;
            border-radius: 10px;
            margin: 20px 0;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🏪 Retail Restock System</h1>
        
        <div class="status">
            <h3><span class="pulse">●</span> System Status</h3>
            <p>Server: <span id="server-status">Checking...</span></p>
            <p>Database: <span id="db-status">Checking...</span></p>
            <p>Cache: <span id="cache-status">Checking...</span></p>
        </div>

        <div id="loading" class="loading"></div>
        
        <div id="actions" style="display: none;">
            <button class="btn" onclick="startRestock()">🏪 Start Restock Session</button>
            <button class="btn" onclick="viewReports()">📊 Monthly Reports</button>
            <button class="btn" onclick="openCacheFix()">🔧 Fix Cache Issues</button>
        </div>

        <div class="cache-info">
            <strong>Cache Version:</strong> ${timestamp}<br>
            <strong>Load Time:</strong> <span id="load-time"></span><br>
            <strong>PWA Mode:</strong> <span id="pwa-mode"></span>
        </div>

        <div id="results" style="display: none; background: rgba(255,255,255,0.2); padding: 20px; border-radius: 15px; margin: 20px 0;">
            <h4>Results</h4>
            <div id="output"></div>
        </div>
    </div>

    <script>
        const startTime = Date.now();
        let appData = { users: [], venues: [], products: [] };

        // Service Worker Registration with Cache Invalidation
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('/sw.js', {
                scope: '/',
                updateViaCache: 'none' // Force no cache for SW updates
            }).then(registration => {
                console.log('SW: Registered successfully');
                
                // Force immediate update
                registration.update();
                
                // Listen for updates
                registration.addEventListener('updatefound', () => {
                    console.log('SW: Update found, installing...');
                    const newWorker = registration.installing;
                    newWorker.addEventListener('statechange', () => {
                        if (newWorker.state === 'installed') {
                            console.log('SW: New service worker installed');
                            if (registration.active) {
                                // New SW is available, reload page
                                window.location.reload(true);
                            }
                        }
                    });
                });
            }).catch(error => {
                console.error('SW: Registration failed:', error);
            });

            // Listen for messages from SW
            navigator.serviceWorker.addEventListener('message', event => {
                if (event.data && event.data.type === 'SW_UPDATED') {
                    console.log('SW: Received update message, reloading...');
                    window.location.reload(true);
                }
            });
        }

        // PWA Detection
        function detectPWA() {
            const isStandalone = window.matchMedia('(display-mode: standalone)').matches;
            const isPWA = window.navigator.standalone || isStandalone;
            document.getElementById('pwa-mode').textContent = isPWA ? 'Yes' : 'No';
            
            if (isPWA) {
                document.querySelector('.cache-info').style.background = 'rgba(40, 167, 69, 0.3)';
            }
        }

        async function loadSystemData() {
            try {
                const loadTime = Date.now() - startTime;
                document.getElementById('load-time').textContent = loadTime + 'ms';
                
                document.getElementById('server-status').textContent = 'Connected';
                document.getElementById('cache-status').textContent = 'Active (v${timestamp})';
                
                // Test API endpoints
                const responses = await Promise.all([
                    fetch('/api/users?_cb=' + Date.now()),
                    fetch('/api/venues?_cb=' + Date.now()), 
                    fetch('/api/products?_cb=' + Date.now())
                ]);

                if (responses.some(r => !r.ok)) {
                    throw new Error('API response error');
                }

                const [users, venues, products] = await Promise.all(
                    responses.map(r => r.json())
                );

                appData.users = users;
                appData.venues = venues;
                appData.products = products;

                document.getElementById('db-status').textContent = 'Connected';
                document.getElementById('loading').style.display = 'none';
                document.getElementById('actions').style.display = 'block';

            } catch (error) {
                document.getElementById('db-status').textContent = 'Error: ' + error.message;
                document.getElementById('loading').style.display = 'none';
                document.getElementById('actions').style.display = 'block';
                console.error('System load error:', error);
            }
        }

        function startRestock() {
            showResults('🎯 <strong>Restock Session Ready</strong><br><br>In production, this opens the full multi-step restock interface with:<br>• User and venue selection<br>• Product inventory management<br>• Par level tracking<br>• Unleashed API integration<br>• Order submission and confirmation');
        }

        function viewReports() {
            showResults('📊 <strong>Monthly Reports Available</strong><br><br>Features:<br>• 6-month trend analysis<br>• Venue-specific reporting<br>• Professional PDF generation<br>• Automated email delivery<br>• Authentic Shopify/WOLFF32 pricing integration');
        }

        function openCacheFix() {
            window.open('/pwa-cache-fix.html', '_blank');
        }

        function showResults(message) {
            document.getElementById('results').style.display = 'block';
            document.getElementById('output').innerHTML = message;
            document.getElementById('results').scrollIntoView({ behavior: 'smooth' });
        }

        // Initialize
        window.addEventListener('load', () => {
            detectPWA();
            loadSystemData();
        });

        // Force cache invalidation on page load
        window.addEventListener('pageshow', (event) => {
            if (event.persisted) {
                console.log('Page loaded from cache, forcing reload');
                window.location.reload(true);
            }
        });
    </script>
</body>
</html>`);
    });

    // Standard 404 for any other missing routes
    app.get('*', (req, res) => {
      console.log(`404 route: ${req.path}`);
      res.status(404).send(`
<!DOCTYPE html>
<html>
<head><title>Page Not Found</title></head>
<body style="background:#6c757d;color:white;padding:50px;text-align:center;font-family:Arial;">
  <h1>Page Not Found</h1>
  <p>Route: ${req.path}</p>
  <p><a href="/" style="color:white;">Return to Home</a></p>
</body>
</html>
      `);
    });

    // ALWAYS serve the app on port 5000
    // this serves both the API and the client.
    // It is the only port that is not firewalled.
    const port = 5000;
    log(`Starting server on port ${port}...`);
    server.listen({
      port,
      host: "0.0.0.0",
      reusePort: true,
    }, () => {
      log(`serving on port ${port}`);
    });
  } catch (error) {
    log(`Failed to start server: ${error}`, "error");
    console.error(error);
    process.exit(1);
  }
})();
